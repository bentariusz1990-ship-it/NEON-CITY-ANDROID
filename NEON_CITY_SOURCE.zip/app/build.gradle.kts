plugins { id("com.android.application") }
android { namespace = "com.neoncity.game"; compileSdk = 35
 defaultConfig { applicationId = "com.neoncity.game"; minSdk = 26; targetSdk = 35; versionCode = 29; versionName = "2.9" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
